from .Singleton import Singleton
